class TrvialTestSuite extends org.scalatest.FunSuite {

	test("The Regexes object must be defined"){
		val regexes : hw.regex.RegexLike = Regexes
	}

	
}